package com.car.bmw.seatbelt;

public class SeatBeltException extends Exception {
	public SeatBeltException(String Message) {
		super(Message);
	}
}
