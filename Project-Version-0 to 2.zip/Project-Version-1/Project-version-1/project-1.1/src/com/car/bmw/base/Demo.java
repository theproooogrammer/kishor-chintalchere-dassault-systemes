package com.car.bmw.base;
import java.util.ArrayList;

import com.car.bmw.door.Door;
import com.car.bmw.door.DoorException;
import com.car.bmw.readings.Distance;
import com.car.bmw.seatbelt.SeatBelt;
import com.car.bmw.seatbelt.SeatBeltException;
import com.car.bmw.wheel.AirException;
import com.car.bmw.wheel.AirInsufficent;
import com.car.bmw.wheel.Wheel;

public class Demo {

	public static Door d1 = new Door(1, false);
	public static Door d2 = new Door(2, false);
	public static Door d3 = new Door(3, false);
	public static Door d4 = new Door(4, false);

	public static Wheel w1 = new Wheel(1);
	public static Wheel w2 = new Wheel(2);
	public static Wheel w3 = new Wheel(3);
	public static Wheel w4 = new Wheel(4);

	public static SeatBelt sb1 = new SeatBelt(1, false);
	public static SeatBelt sb2 = new SeatBelt(2, false);
	public static SeatBelt sb3 = new SeatBelt(3, false);
	public static SeatBelt sb4 = new SeatBelt(4, false);

	public static void main(String[] args) {

		BMW obj1 = new BMW(1111, 30, "White", "ABC",250,30);
		obj1.addDoor(d1);
		obj1.addDoor(d2);
		obj1.addDoor(d3);
		obj1.addDoor(d4);
		
		ArrayList <Door>doorsList=obj1.getDoorsList();
		for(Door door:doorsList){
			if(door.getId()==1)
				System.out.println(door.isStatus());
		}
		System.out.println(obj1);

		System.out.println("\nBasic Features of: - " + obj1.getLogo());
		obj1.canDrive();
		obj1.canFillFuel();
		obj1.doorLock();
		obj1.noOfPassenger();
		System.out.println();
		System.out.println("\nFeatures of: - " + obj1.getLogo());
		obj1.hasGPS();
		obj1.customize();
		System.out.println();

		System.out.println("Initial Checks Before Starting Ride..\n");

		// ======================================================================
		// Doors
		// ======================================================================

		ArrayList<Door> DoorsList = new ArrayList<Door>();
		DoorsList.add(d1);
		DoorsList.add(d2);
		DoorsList.add(d3);
		DoorsList.add(d4);

		// ======================================================================
		// Seat Belt
		// ======================================================================
		ArrayList<SeatBelt> SeatBeltList = new ArrayList<SeatBelt>();
		SeatBeltList.add(sb1);
		SeatBeltList.add(sb2);
		SeatBeltList.add(sb3);
		SeatBeltList.add(sb4);

		Distance distance = new Distance();

		// ======================================================================
		// Wheels
		// ======================================================================

		ArrayList<Wheel> WheelsList = new ArrayList<Wheel>();
		WheelsList.add(w1);
		WheelsList.add(w2);
		WheelsList.add(w3);
		WheelsList.add(w4);

		try {

			System.out.println("Doors Check......");
			DoorsCheck(DoorsList);
			System.out.println("\nAll Doors Closed Can Start the Ride..\n");

			System.out.println("Seat Belt Check......");
			SeatBeltCheck(SeatBeltList);
			System.out.println("\nSeat Belts Closed Can Start the Ride..\n");

			System.out.println("Air Check Before Starting Ride......");

			distance.setD(0);
			WheeksAirCheck(WheelsList, distance);
			System.out.println("Starting the ride...\n");

			distance.setD(50);
			WheeksAirCheck(WheelsList, distance);

			distance.setD(100);
			WheeksAirCheck(WheelsList, distance);

			distance.setD(150);
			WheeksAirCheck(WheelsList, distance);

		} catch (Exception exception) {
			System.out.println(exception);
		}

	}

	static void SeatBeltCheck(ArrayList<SeatBelt> seatBeltList)
			throws SeatBeltException {

		// sb1.SeatBeltCheck();
		for (SeatBelt SeatBelt : seatBeltList) {
			SeatBelt.setStatus(true);
		}
		// sb1.setStatus(false);
		// sb3.setStatus(false);

		for (SeatBelt SeatBelt : seatBeltList) {
			SeatBelt.SeatBeltCheck();
		}
	}

	static void WheeksAirCheck(ArrayList<Wheel> wheelsList, Distance distance)
			throws AirInsufficent, AirException {

		double dist = distance.getD();

		Wheel.AirAlert(dist);

		for (Wheel wheel : wheelsList) {
			wheel.checkAir(dist);
		}

		System.out.println();

		// distance.setD(75);
		// dist = distance.getD();

		// Assuming Tyre 3 to be punctured.
		// w3.setCapacity(60);
		// w3.checkAir(dist);

	}

	static void DoorsCheck(ArrayList<Door> DoorsList) throws DoorException {

		// d1.doorCheck();
		for (Door door : DoorsList) {
			door.setStatus(true);
		}

		// d3.setStatus(false);

		for (Door door : DoorsList) {
			door.doorCheck();
		}
	}

}
