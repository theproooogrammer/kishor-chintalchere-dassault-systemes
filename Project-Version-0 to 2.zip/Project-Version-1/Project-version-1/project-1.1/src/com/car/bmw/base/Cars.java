package com.car.bmw.base;
import com.car.bmw.components.Engine;
import com.car.bmw.components.Transmission;
import com.car.bmw.wheel.Wheel;

public class Cars implements Vehicle {

	Wheel w1 = new Wheel(1);
	Wheel w2 = new Wheel(2);
	Wheel w3 = new Wheel(3);
	Wheel w4 = new Wheel(4);

	Engine engine = new Engine();
	Transmission transmission = new Transmission();

	public void canDrive() {
		System.out.println("Drivering....");

	}

	public void canFillFuel() {
		System.out.println("Fuel Filling...");

	}

	public void doorLock() {
		System.out.println("Door Lock...");

	}

	public void noOfPassenger() {
		System.out.println("No of Passenger 4 s");

	}

	// ArrayList<Wheel>list=new ArrayList<Wheel>();
	// list.add(w1);

}
