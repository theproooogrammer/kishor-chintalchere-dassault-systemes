package com.car.bmw.wheel;

public class AirInsufficent extends Exception {

	public AirInsufficent(String Message) {
		super(Message);
	}

}
