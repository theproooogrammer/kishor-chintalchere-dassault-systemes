package com.car.bmw.seatbelt;

import com.car.bmw.door.DoorException;

public class SeatBelt {
	int id;
	boolean status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public SeatBelt(int id, boolean status) {
		super();
		this.id = id;
		this.status = status;
	}

	public void SeatBeltCheck() throws SeatBeltException {

		if (status == false) {

			if (getId() == 3 || getId() == 4) {
				System.out.println("Put on Seat Belt No " + getId());
			} else {
				SeatBeltException se = new SeatBeltException(
						"Put on Seat Belt No " + getId() + " to Start the ride");
				throw se;
			}

		} else {
			System.out.println("Seat Belt No " + getId() + " Closed ");
		}

	}

}
