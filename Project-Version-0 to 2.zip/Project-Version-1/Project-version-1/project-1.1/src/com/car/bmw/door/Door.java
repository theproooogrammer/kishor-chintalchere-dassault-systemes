package com.car.bmw.door;

import java.io.Serializable;

public class Door implements Serializable {
	int id;
	boolean status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Door(int id, boolean status) {
		super();
		this.id = id;
		this.status = status;
	}

	public void doorCheck() throws DoorException {

		if (status == false) {
			DoorException de = new DoorException("Close Door No " + getId()
					+ " to Start the ride");
			throw de;
		} else {
			System.out.println("Door no. " + getId() + " closed");
		}
	}
}
