package com.car.bmw.showroom;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.car.bmw.base.BMW;

public class BMWObjectSerializationTest {

	public static void main(String[] args) {

		BMW bmw1 = new BMW(1001, 30, "White", "ABC", 250, 30);
		BMW bmw2 = new BMW(1002, 35, "Black", "XYZ", 280, 20);
		BMW bmw3 = new BMW(1003, 40, "Yellow", "PQR", 300, 27);
		BMW bmw4 = new BMW(1004, 32, "Red", "XYZ", 280, 33);
		BMW bmw5 = new BMW(1005, 38, "White", "LMN", 270, 35);

		ArrayList<BMW> allBMW = new ArrayList<BMW>();

		try {
			FileOutputStream fout = new FileOutputStream("BMW.TXT");
			System.out.println("File is ready...");
			allBMW.add(bmw1);
			allBMW.add(bmw2);
			allBMW.add(bmw3);
			allBMW.add(bmw4);
			allBMW.add(bmw5);

			ObjectOutputStream oos = new ObjectOutputStream(fout);
			System.out.println("Object output stream is also ready...");

			oos.writeObject(allBMW); // can we serialize it??
			System.out.println("ArrayList Object is serialized ..... ");

			oos.close();
			fout.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
}
