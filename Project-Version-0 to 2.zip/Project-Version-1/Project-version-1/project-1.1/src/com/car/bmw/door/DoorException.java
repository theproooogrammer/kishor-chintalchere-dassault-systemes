package com.car.bmw.door;

public class DoorException extends Exception {
	public DoorException(String Message) {
		super(Message);
	}
}
