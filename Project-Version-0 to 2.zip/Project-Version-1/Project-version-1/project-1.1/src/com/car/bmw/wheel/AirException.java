package com.car.bmw.wheel;

public class AirException extends Exception {

	public AirException(String Message) {
		super(Message);
	}

}

