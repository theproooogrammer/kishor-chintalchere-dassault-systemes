package com.car.bmw.showroom;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import com.car.bmw.base.BMW;

public class BMWObjectDeSerializationTest {

	public static void main(String[] args) {
		//BMW bmw = null;

		try {
			FileInputStream fin = new FileInputStream("BMW.TXT");
			System.out.println("File is ready to read...");

			ObjectInputStream ois = new ObjectInputStream(fin);
			System.out.println("Object input stream is also ready to read..");

			ArrayList<BMW> allBMW = null;

			allBMW = (ArrayList<BMW>) ois.readObject();
			System.out.println("Object is de-serialized ..... ");

			for (BMW bmw : allBMW) {
				System.out.println("bmw " + bmw);
			}

			ois.close();
			fin.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
