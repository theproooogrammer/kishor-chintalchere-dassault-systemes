package com.car.bmw.wheel;

import com.car.bmw.readings.Distance;

public class Wheel {

	int id;
	double capacity = 100.00;

	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	public Wheel(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	Distance d = new Distance();

	// For All Wheels
	public static void AirAlert(double dist) throws AirException {
		if (dist > 100) { // 100KM

			AirException ae = new AirException(
					" Air Check Alert for Wheels at Distance " + dist);

			throw ae;

		}
	}

	public void checkAir(double dist) throws AirInsufficent, AirException {

		if (capacity < 70) {

			AirInsufficent ai = new AirInsufficent("Insufficient Air for "
					+ getId() + " at Distance. " + dist
					+ "Wheel Air Capacity is : " + getCapacity());

			throw ai;
		}

		else {
			System.out.println("ALL Good in wheel no. " + getId()
					+ " at Distance " + dist);
		}
	}
}
