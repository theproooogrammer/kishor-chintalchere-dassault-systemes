package com.car.bmw.components;

public class Transmission {

}
