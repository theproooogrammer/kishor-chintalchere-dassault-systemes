package com.car.bmw.showroom;

public class BMWShowroom {

	public static void main(String[] args) {

	}

}
