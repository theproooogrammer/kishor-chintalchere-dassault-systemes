package com.car.bmw.base;
public interface Vehicle {

	void canDrive();

	void canFillFuel();

	void doorLock();

	void noOfPassenger();

}
