package com.car.bmw.base;

import java.io.Serializable;
import java.util.ArrayList;

import com.car.bmw.door.Door;

public final  class BMW extends Cars implements Serializable {

	int id;
	double tank;
	String color;
	String Model;
	double topSpeed;
	double Acceleration;
	final String Logo = "BMW";
	
	ArrayList<Door> doorsList=new ArrayList<Door>();

	public ArrayList<Door> getDoorsList() {
		return doorsList;
	}

	public void setDoorsList(ArrayList<Door> doorsList) {
		this.doorsList = doorsList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTank() {
		return tank;
	}

	public void setTank(double tank) {
		this.tank = tank;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getModel() {
		return Model;
	}

	public void setModel(String model) {
		Model = model;
	}

	public double getTopSpeed() {
		return topSpeed;
	}

	public void setTopSpeed(double topSpeed) {
		this.topSpeed = topSpeed;
	}

	public double getAcceleration() {
		return Acceleration;
	}

	public void setAcceleration(double acceleration) {
		Acceleration = acceleration;
	}

	public String getLogo() {
		return Logo;
	}

	public BMW(int id, double tank, String color, String model,
			double topSpeed, double acceleration) {
		super();
		this.id = id;
		this.tank = tank;
		this.color = color;
		Model = model;
		this.topSpeed = topSpeed;
		Acceleration = acceleration;
		doorsList.add(new Door(1, false));
	}

	public void addDoor(Door door){
		doorsList.add(door);
	}
	@Override
	public String toString() {
		return "BMW [id=" + id + ", tank=" + tank + ", color=" + color
				+ ", Model=" + Model + ", topSpeed=" + topSpeed
				+ ", Acceleration=" + Acceleration + ", Logo=" + Logo + "]";
	}

	public void canDrive() {
		System.out.println(Logo + " Can be Driven ");
	}

	public void canFillFuel() {
		System.out.println(Logo + " Fuel can be Filled");

	}

	public void doorLock() {
		System.out.println(Logo + " Doors can be Locked");

	}

	public void noOfPassenger() {
		System.out.println(Logo + "No of Passenger 4 s");

	}

	public void hasGPS() {
		System.out.println(Logo + " has GPS ");

	}

	final public void customize() {
		System.out
				.println(Logo + " can be customize as per user's requirment ");

	}

}
