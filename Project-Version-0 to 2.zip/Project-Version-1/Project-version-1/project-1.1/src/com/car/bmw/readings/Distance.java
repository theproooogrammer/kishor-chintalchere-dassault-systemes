package com.car.bmw.readings;

public class Distance {

	double d = 00;// Distance covered

	public double getD() {
		return d;
	}

	public void setD(double d) {
		this.d = d;
	}

}
