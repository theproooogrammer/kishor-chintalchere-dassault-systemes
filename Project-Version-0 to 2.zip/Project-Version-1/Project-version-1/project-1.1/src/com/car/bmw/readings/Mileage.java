package com.car.bmw.readings;

public class Mileage {

	double m = 40;// Milage

	public double getM() {
		return m;
	}

	public void setM(double m) {
		this.m = m;
	}

}
