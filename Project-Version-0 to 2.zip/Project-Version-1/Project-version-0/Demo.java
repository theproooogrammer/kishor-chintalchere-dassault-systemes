class Demo{
	
	public static void main(String args[]){
		BMW obj1=new BMW();
		
		obj1.start();
		
		Distance distance=new Distance();
		Milage milage=new Milage();
		
		FuelConsumed fuelconsumed=obj1.consumed(distance,milage);
		fuelconsumed.display();
		
		Wheel[] w;
		w=new Wheel[4];
		
		double dist=0;
		
		for(int i=1;i<=4;i++)
			wl[i]=new Wheel(i);
		
		dist=distance.setD(50);
		
		for(int i=1;i<=4;i++)
			wl[i].checkAir(dist);
		
		dist=distance.setD(100);
		
		try{
			for(int i=1;i<=4;i++)
				wl[i].checkAir(dist);
		}catch(airInsufficent ai){
			System.out.println(ai);
		}
		
		
	}
	
}
class BMW extends Car{

}
class Car{
	
	Engine engine=new Engine();
	Transmission tm=new Transmission();
	Wheel[] w;
	w=new Wheel[4];
	
	for(int i=1;i<=4;i++)
		wl[i]=new Wheel(i);
	
	FuelConsumed consumed(Distance distance,Milage milage){
		return new FuelConsumed(distance.getD()*distance.getM());
	}
	
}

class Wheel(

	int id;
	Double cap=100;
	
	Distance d=new Distance();
	
	Wheel(int id){this.id=id;}
	
	int getId(){return Wheel.id; }
	
	void checkAir(double dist) throws airInsufficent{
		if(dist>100){//100KM
			airInsufficent ai=new airInsufficent("Insufficient Air for "+wheel.getId);
			throw ai;
		
		}else{
			System.out.println("ALL Good!! in wheel no. "+wheel.getId);
		}
	}
	
)

class airInsufficent extends Exception{
	
	public airInsufficent(String Message){
		super(Message);
	}
}

class FuelConsumed{
	
	double amt=10;
	FuelConsumed(double amt){
		this.amt=amt;
	}
	
	void display(){
		SOP(FuelConsumed.amt);
	}
}

class Distance{
	double d=00;//Distance covered	
	double getD(){return d;}
	void setD(double d){this.d=d;}
}

class Milage{
	double m=40;//Milage
	double getM(){return M;}
	
}

class Engine{
}
class Transmission(
)

